package edu.umsl.encapsulation;

public class Address {
	
	private String streetName;
	private String houseNumber;
	private String apartmentNumber;
	private String zipCode;
	
}
package edu.umsl.encapsulation;

import java.util.Date;
import java.util.GregorianCalendar;

public class App {
	public static void main(String[] args)
	{

	Bookstore Bookstore = new Bookstore();
	
	GregorianCalendar calendar = new GregorianCalendar(1989,2,3);
	Date date = new Date(calendar.getTimeInMillis());
	
	
	Bookstore.setName("The Nook");
	Bookstore.setId("381610");
	Bookstore.setAddress("Address");
	Bookstore.setBook("Book");
	
	System.out.println(Bookstore.getName());
	System.out.println(Bookstore.getId());
	System.out.println(Bookstore.getAddress());
	System.out.println(Bookstore.getBook());
	
	// I cannot seem to pull the Address and Book correctly. I don't understand how to populate 
	// street name, author, isbn, etc. 
	
	
	
	
	
	
	
	
	
	}
	}

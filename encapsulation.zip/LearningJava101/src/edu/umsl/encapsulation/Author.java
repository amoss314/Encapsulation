package edu.umsl.encapsulation;

import java.util.Date;

public class Author {
	
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private Address Address;
	

}

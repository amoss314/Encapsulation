package edu.umsl.encapsulation;

public class Book {

	private String name;
	private String isbn;
	private Author author;
	
	
}
